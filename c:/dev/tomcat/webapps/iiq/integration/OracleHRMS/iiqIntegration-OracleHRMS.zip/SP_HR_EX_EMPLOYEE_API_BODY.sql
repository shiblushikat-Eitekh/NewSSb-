create or replace PACKAGE  body  SP_HR_EX_EMPLOYEE_API as

procedure actual_termination_emp
  (p_validate                      in     boolean  default false
  ,p_effective_date                in     date
  ,p_period_of_service_id          in     number
  ,p_object_version_number         in out nocopy number
  ,p_actual_termination_date       in     date
  ,p_last_standard_process_date    in out nocopy date
  ,p_person_type_id                in     number   default hr_api.g_number
  ,p_assignment_status_type_id     in     number   default hr_api.g_number
  ,p_leaving_reason                in     varchar2 default hr_api.g_varchar2
  ,p_atd_new                       in     number   default hr_api.g_true_num
  ,p_lspd_new                      in     number   default hr_api.g_true_num
  ,p_supervisor_warning               out nocopy boolean
  ,p_event_warning                    out nocopy boolean
  ,p_interview_warning                out nocopy boolean
  ,p_review_warning                   out nocopy boolean
  ,p_recruiter_warning                out nocopy boolean
  ,p_asg_future_changes_warning       out nocopy boolean
  ,p_entries_changed_warning          out nocopy varchar2
  ,p_pay_proposal_warning             out nocopy boolean
  ,p_dod_warning                      out nocopy boolean
  ,p_alu_change_warning               out nocopy varchar2
  )is
begin
HR_EX_EMPLOYEE_API.actual_termination_emp
( p_validate => p_validate,
  p_effective_date => p_effective_date,
  p_period_of_service_id => p_period_of_service_id,
  p_object_version_number => p_object_version_number,
  p_actual_termination_date => p_actual_termination_date,
  p_last_standard_process_date => p_last_standard_process_date,
  p_person_type_id => p_person_type_id,
  p_assignment_status_type_id => p_assignment_status_type_id,
  p_leaving_reason => p_leaving_reason,
  p_atd_new => p_atd_new,
  p_lspd_new => p_lspd_new,
  p_supervisor_warning => p_supervisor_warning,
  p_event_warning => p_event_warning,
  p_interview_warning => p_interview_warning,
  p_review_warning => p_review_warning,
  p_recruiter_warning => p_recruiter_warning,
  p_asg_future_changes_warning => p_asg_future_changes_warning,
  p_entries_changed_warning => p_entries_changed_warning,
  p_pay_proposal_warning => p_pay_proposal_warning,
  p_dod_warning => p_dod_warning,
  p_alu_change_warning => p_alu_change_warning
);
end actual_termination_emp;

  procedure update_term_details_emp
  (p_validate                      in     boolean  default false
  ,p_effective_date                in     date
  ,p_period_of_service_id          in     number
  ,p_object_version_number         in out nocopy number
  ,p_termination_accepted_person   in     number   default hr_api.g_number
  ,p_accepted_termination_date     in     date     default hr_api.g_date
  ,p_comments                      in     varchar2 default hr_api.g_varchar2
  ,p_leaving_reason                in     varchar2 default hr_api.g_varchar2
  ,p_notified_termination_date     in     date     default hr_api.g_date
  ,p_projected_termination_date    in     date     default hr_api.g_date
  ) is 
  begin 
  HR_EX_EMPLOYEE_API.update_term_details_emp
  (p_validate => p_validate,
  p_effective_date => p_effective_date,
  p_period_of_service_id => p_period_of_service_id,
  p_object_version_number => p_object_version_number,
  p_termination_accepted_person => p_termination_accepted_person,
  p_accepted_termination_date => p_accepted_termination_date,
  p_comments => p_comments,
  p_leaving_reason => p_leaving_reason,
  p_notified_termination_date => p_notified_termination_date,
  p_projected_termination_date => p_projected_termination_date
  );
end update_term_details_emp;

  procedure final_process_emp
  (p_validate                      in     boolean  default false
  ,p_period_of_service_id          in     number
  ,p_object_version_number         in out nocopy number
  ,p_final_process_date            in out nocopy date
  ,p_org_now_no_manager_warning       out nocopy boolean
  ,p_asg_future_changes_warning       out nocopy boolean
  ,p_entries_changed_warning          out nocopy varchar2
  ) is
  begin
HR_EX_EMPLOYEE_API.final_process_emp
 (p_validate => p_validate,
  p_period_of_service_id => p_period_of_service_id,
  p_object_version_number => p_object_version_number,
  p_final_process_date => p_final_process_date,
  p_org_now_no_manager_warning => p_org_now_no_manager_warning,
  p_asg_future_changes_warning => p_asg_future_changes_warning,
  p_entries_changed_warning => p_entries_changed_warning
  );
end final_process_emp;

end SP_HR_EX_EMPLOYEE_API;